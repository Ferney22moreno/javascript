'use strict'

let angelica = {
  nombre: 'Angelica',
  apellido: 'Paredes',
  altura: 1.65,
  edad: 22,
  cantidadDeLibros: 10
}
let mery = {
  nombre: 'Mery',
  apellido: 'Carrion',
  altura: 1.60,
  edad: 48,
  cantidadDeLibros: 2
}
let ferney = {
  nombre: 'Ferney',
  apellido: 'Moreno',
  altura: 1.75,
  edad: 27,
  cantidadDeLibros: 40
}
let juan = {
  nombre: 'Juan',
  apellido: 'Valbuena',
  altura: 1.10,
  edad: 7,
  cantidadDeLibros: 7
}

const masAltos = ({ altura }) => altura > 1.6
const masViejos = ({ edad }) => edad > 20
const pasarAlturaCms = persona => ({
    ...persona,
    altura: persona.altura * 100
})

const reducer = (acumulador, {cantidadDeLibros}) => acumulador + cantidadDeLibros
const edadesReduce = (acum, persona) => acum + persona.edad

let personas = [angelica, mery, ferney, juan]

const filtrarPorAltura = personas.filter(masAltos)
const filtrarPorEdad = personas.filter(masViejos)
const alturaCms = personas.map(pasarAlturaCms)
const totalLibros = personas.reduce(reducer, 0)
const totalEdades = personas.reduce(edadesReduce, 0)

console.log(filtrarPorAltura)
console.log(filtrarPorEdad)
console.log(alturaCms)
console.log(totalLibros)
console.log(totalEdades)
