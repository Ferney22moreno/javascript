'use strict'

let signo = prompt('¿cual es su signo zodiacal?')

switch (signo) {
  case 'piscis':
    console.log('El ritmo de trabajo en estos últimos días de noviembre será bastante ajetreado y tenso, esto no deberá afectar a las decisiones que tome ya que hay mucho en juego, por ello Piscis deberá centrar sus expectativas del 2018 pensando con objetividad hacia el futuro, que viene muy prometedor para Piscis en su carrera.')
    break
  case 'tauro':
    console.log('Tauro descubrirá este mes sus habilidades y fortaleza que le permitirán destacar en su trabajo, esto le dará la confianza necesaria para incursionar en cualquier ámbito de su carrera adquiriendo nuevos retos profesionales que Tauro podría emprender antes de que acabe noviembre con propuestas que despierten su destreza.')
    break
  case 'libra':
    console.log('Será conveniente zanjar cualquier altercado en el trabajo antes de acabar el mes de noviembre, con ello Libra podrá enfocarse en nuevos retos que le permitirá en este periodo del 2018 ser más productivo en su carrera, lo que será conveniente que si Libra quiere alcanzar su mayor objetivo: el éxito.')
    break
  default:
    console.log('No es un signo zodiacal valido')
    break
}
