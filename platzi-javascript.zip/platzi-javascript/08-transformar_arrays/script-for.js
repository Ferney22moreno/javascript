'use strict'

let angelica = {
  nombre: 'Angelica',
  apellido: 'Paredes',
  altura: 1.65,
  edad: 22
}
let mery = {
  nombre: 'Mery',
  apellido: 'Carrion',
  altura: 1.60,
  edad: 48
}
let ferney = {
  nombre: 'Ferney',
  apellido: 'Moreno',
  altura: 1.75,
  edad: 27
}
let juan = {
  nombre: 'Juan',
  apellido: 'Valbuena',
  altura: 1.10,
  edad: 7
}

const masAltos = ({ altura }) => altura > 1.6
const masViejos = ({ edad }) => edad > 20
const pasarAlturaCms = persona => ({
    ...persona,
    altura: persona.altura * 100
})

let personas = [angelica, mery, ferney, juan]

const filtrarPorAltura = personas.filter(masAltos)
const filtrarPorEdad = personas.filter(masViejos)
const alturaCms = personas.map(pasarAlturaCms)

console.log(filtrarPorAltura)
console.log(filtrarPorEdad)
console.log(alturaCms)
