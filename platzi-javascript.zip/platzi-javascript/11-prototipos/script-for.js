'use strict'

function Persona (nombre, apellido, altura, sexo) {
  this.nombre = nombre
  this.apellido = apellido
  this.altura = altura
}

Persona.prototype.alturaPersona = function () {
  this.altura > 1.80 ? console.log(`Soy ${this.nombre} y mido ${this.altura} mts`) : console.log(`${this.nombre} no eres lo suficientemente ${this.sexo === 'masculino' ? 'alto' : 'alta'}, apenas mides ${this.altura} mts`)
}

let ferney = new Persona('Ferney', 'Moreno', 1.75, 'masculino')
let miguel = new Persona('Miguel', 'Landazuri', 1.82, 'masculino')
let daniel = new Persona('Daniel', 'Wilches', 1.81, 'masculino')
let angelica = new Persona('Angelica', 'Paredes', 1.65, 'Femenino')

ferney.alturaPersona()
miguel.alturaPersona()
daniel.alturaPersona()
angelica.alturaPersona()
