'use strict'

// ******************** estructuras repetitivas fro

let ferney = {

  nombre: 'Ferney',
  apellido: 'Moreno',
  edad: 27,
  peso: 65

}
console.log(`A principio de 2018 ${ferney.nombre} pesaba ${ferney.peso}kgs`)

const INCREMENTO_PESO = 0.2
const DECREMENTO_PESO = 0.15

const aumentoDePeso = persona => persona.peso += INCREMENTO_PESO
const adelgazarDePeso = persona => persona.peso -= DECREMENTO_PESO
const comeMucho = () => Math.random() < 0.3
const haceEjercicio = () => Math.random() < 0.4

const META_PESO = ferney.peso - 3
let dias = 0
while (ferney.peso > META_PESO) {
  if (comeMucho()) {
    aumentoDePeso(ferney)
  }

  if (haceEjercicio()) {
    adelgazarDePeso(ferney)
  }
  dias++
}
console.log(`Pasaron ${dias} para que ${ferney.nombre} bajara 3 kilos`)
console.log(`A final de 2018 ${ferney.nombre} pesa ${ferney.peso.toFixed(2)}kgs`)
