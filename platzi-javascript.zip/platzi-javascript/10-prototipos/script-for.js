'use strict'

function Persona(nombre, apellido, edad) {
  this.nombre = nombre
  this.apellido = apellido
  this.edad = edad
}

let ferney = new Persona('Ferney', 'Moreno', 27);
let angelica = new Persona('ANgelica', 'Paredes', 23);