'use strict';

// let insertName = prompt('insert your name');
//
// let getAmountOfLetterInTheName = insertName.length - 1;
// let getLastLettterOfName = insertName.charAt(getAmountOfLetterInTheName);
// let finalLetter = `The last letter in his name is ${getLastLettterOfName}`;
//
// console.log(finalLetter);

// var name = 'Ferney', edad = 27;
//
// function imprimirEdad(name, edad) {
//   console.log(`${name} tiene ${edad} años`);
// }
//
// imprimirEdad('Angelica', 22);

/////*********** alcance de funciones
// var name = 'Ferney';
//
// function imprimirNombreEnMayusculas(myName){
//   myName = myName.toUpperCase();
//   console.log(myName);
// }
//
// imprimirNombreEnMayusculas(name);
// console.log(name);
/////*********** alcance de funciones


/////*********** objetos y funciones

// var miSuma = {
//   n1:5, n2: 20
// }
//
// function sumar({n1, n2}){
//
//   var operacion = n1 * n2;
//
//   console.log(operacion);
// }
//
// sumar(miSuma);
// sumar({n1:3, n2: 40}); //cambiando los valores del objeto


// var ferney = {
//   nombre: 'Ferney',
//   apellido: 'Moreno',
//   edad: 27
// }
//
// var angelica = {
//   nombre: 'Angelica',
//   apellido: 'Paredes',
//   edad: 22
// }
//
// function imprimirNombreEnMayusculas({nombre, apellido}){
//   var nombres = nombre.toUpperCase();
//   var apellidos = apellido.toUpperCase();
//   console.log(`me llamo ${nombres} ${apellidos}`);
// }
//
// imprimirNombreEnMayusculas(ferney);
// imprimirNombreEnMayusculas(angelica);
//
// imprimirNombreEnMayusculas({nombre: 'Mery', apellido: 'Carrion'});


//destructuring objects***************************

var ferney = {
  nombre: 'Ferney',
  apellido: 'Moreno',
  edad: 27
}

var angelica = {
  nombre: 'Angelica',
  apellido: 'Paredes',
  edad: 22
}

var juan = {
  nombre: 'Juan',
  apellido: 'Valbuena',
  edad: 6
}

function imprimirNombreEnMayusculas(persona){
  var {nombre, edad} = persona;
  console.log(`Hola, me llamo ${nombre} y tengo ${edad} años`);
}

imprimirNombreEnMayusculas(ferney);
imprimirNombreEnMayusculas(angelica);


// pass by value - pass by reference

function cumpleanos(persona){
  return{
    ...persona,
    edad: persona.edad + 1
  }
}

// function cumpleano(edad){
//   edad += 1;
// }


//comparando objetos

// si comparamos estos dos objetos el resultado sera FALSE, ya que son objetos distintos porque ocupan un espacio diferente en la memoria, por mas que tengan el mismo KEY y VALUE.
var persona = {
  nombre : 'Angelica'
}
var otraPersona = {
  nombre : 'Angelica'
}

var nuevaPersona = {
  ...persona
}

// si comparamos estos dos objetos el resultado sera TRUE, ya que el segundo objeto hace referencia al primero, por lo tanto ocuoan el mismo espacio en memoria
var humano = {
  nombre: 'Ferney'
}

var otroHumano = humano;



//****************condicionales****************//

var personaje = {
  nombre: 'Ferney',
  apellido: 'Moreno',
  edad: 27,
  desarrollador: true,
  musico: false,
  disenador: true,
  filosofo: false
}

const imprimirProfesionPersona = persona => {

  console.log(`La profesion de ${persona.nombre} es:`);

  if(persona.desarrollador){
    console.log('Desarrollador');
  }
  if(persona.musico){
    console.log('Músico');
  }
  if(persona.disenador){
    console.log('Diseñador');
  }
  if(persona.filosofo){
    console.log('Filosofo');
  }

}

imprimirProfesionPersona(personaje);

// const imprimirSiEsMayorDeEdad = persona => {
//
//   let edadLegalColombia = 18;
//
//   console.log(`${persona.nombre} tiene ${persona.edad} años, por lo tanto:`);
//
//   if(persona.edad > edadLegalColombia){
//     console.log('Es mayor de edad');
//   }else{
//     console.log('Es menor de edad');
//   }
//
// }
//
// imprimirSiEsMayorDeEdad(personaje);


//*********************funciones que retornan valores *****************************

const EDAD_LEGAL_COLOMBIA = 18;
const esMayorDeEdad = persona => persona.edad > EDAD_LEGAL_COLOMBIA;

const imprimirSiEsMayorDeEdad = persona => {

  console.log(`${persona.nombre} tiene ${persona.edad} años, por lo tanto:`);

  if(esMayorDeEdad(persona)){
    console.log('Es mayor de edad');
  }else{
    console.log('Es menor de edad');
  }

}
