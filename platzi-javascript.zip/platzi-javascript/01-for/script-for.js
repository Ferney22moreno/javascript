'use strict'

// ******************** estructuras repetitivas fro

let ferney = {

  nombre: 'Ferney',
  apellido: 'Moreno',
  edad: 27,
  peso: 65

}
console.log(`A principio de 2018 ${ferney.nombre} pesaba ${ferney.peso}kgs`)

const INCREMENTO_PESO = 0.2
const DECREMENTO_PESO = 0.15

const aumentoDePeso = persona => persona.peso += INCREMENTO_PESO
const adelgazarDePeso = persona => persona.peso -= DECREMENTO_PESO

for (let i = 1; i <= 365; i++) {
  let randomNumber = Math.random(

  if(randomNumber < 0.25) { // aumenta de peso
    aumentoDePeso(ferney)
  } else if (rand omNumber < 0.5) { // desminuye de peso
    adelgazarDePeso(ferney)
  }
}

console.log(`A final de 2018 ${ferney.nombre} pesa ${ferney.peso.toFixed(2)}kgs`)
