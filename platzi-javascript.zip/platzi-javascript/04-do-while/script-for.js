'use strict'

let contador = 0

const llueve = () => Math.random() < 0.30
console.log(llueve())
do {
  contador++
} while (!llueve())

let frecuencia = contador > 1 ? 'veces' : 'vez'

console.log(`fui a ver si llovía ${contador} ${frecuencia}`)
