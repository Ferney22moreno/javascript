'use strict'

let angelica = {
  nombre: 'Angelica',
  apellido: 'Paredes',
  altura: 1.65,
  edad: 22
}
let mery = {
  nombre: 'Mery',
  apellido: 'Carrion',
  altura: 1.60,
  edad: 48
}
let ferney = {
  nombre: 'Ferney',
  apellido: 'Moreno',
  altura: 1.75,
  edad: 27
}
let juan = {
  nombre: 'Juan',
  apellido: 'Valbuena',
  altura: 1.10,
  edad: 7
}

let personas = [angelica, mery, ferney, juan]

for (let i = 0; i < personas.length; i++) {
  let persona = personas[i]
  console.log(`${persona.nombre} mide ${persona.altura} mts y tiene ${persona.edad} años`)
}
